import azure.functions as func
import logging
import sys
import os

# Asegurar que la carpeta actual está en el path para poder importar main
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from main import procesar_correos

app = func.FunctionApp()

# Ejecutar en el minuto 0 de cada hora (Ej: 1:00, 2:00, 3:00...)
@app.timer_trigger(schedule="0 0 * * * *", arg_name="myTimer", run_on_startup=True, use_monitor=False) 
def timer_trigger(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.info('El temporizador se retrasó.')
    
    logging.info('Iniciando extracción automatizada de correos...')
    try:
        procesar_correos()
        logging.info('Extracción finalizada con éxito.')
    except Exception as e:
        logging.error(f'Error en la extracción: {e}')
