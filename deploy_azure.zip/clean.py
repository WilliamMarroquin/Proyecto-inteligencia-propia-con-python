import os
import mysql.connector
from dotenv import load_dotenv

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")

def clean():
    parts = DATABASE_URL.replace("mysql://", "").split("@")
    user_pass = parts[0].split(":")
    host_db = parts[1].split("/")
    host_port = host_db[0].split(":")
    db_name = host_db[1].split("?")[0]
    
    conn = mysql.connector.connect(
        user=user_pass[0],
        password=user_pass[1],
        host=host_port[0],
        port=int(host_port[1]),
        database=db_name,
        ssl_disabled=False
    )
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Pago")
    conn.commit()
    print("Pagos huerfanos borrados via Python.")
    cursor.close()
    conn.close()

if __name__ == "__main__":
    clean()
