import os
import imaplib
import email
from email.header import decode_header
import pandas as pd
import mysql.connector
from io import BytesIO
from dotenv import load_dotenv
from datetime import datetime
import cloudinary
import cloudinary.uploader
import random
import string
import time
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# Cargar variables de entorno
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")

# Configurar Cloudinary
cloudinary.config(
    cloud_name=os.getenv("CLOUDINARY_CLOUD_NAME"),
    api_key=os.getenv("CLOUDINARY_API_KEY"),
    api_secret=os.getenv("CLOUDINARY_API_SECRET")
)

def decrypt(encrypted_text: str) -> str:
    if not encrypted_text or ':' not in encrypted_text:
        return encrypted_text
    try:
        parts = encrypted_text.split(':')
        iv = bytes.fromhex(parts[0])
        ciphertext = bytes.fromhex(':'.join(parts[1:]))
        key = bytes.fromhex(ENCRYPTION_KEY)
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted_padded = decryptor.update(ciphertext) + decryptor.finalize()
        # Remove PKCS7 padding
        padding_len = decrypted_padded[-1]
        return decrypted_padded[:-padding_len].decode('utf-8')
    except Exception as e:
        print(f"Error descifrando: {e}")
        return encrypted_text

def get_db_connection():
    parts = DATABASE_URL.replace("mysql://", "").split("@")
    user_pass = parts[0].split(":")
    host_db = parts[1].split("/")
    host_port = host_db[0].split(":")
    db_name = host_db[1].split("?")[0]
    
    conn = mysql.connector.connect(
        user=user_pass[0],
        password=user_pass[1],
        host=host_port[0],
        port=int(host_port[1]),
        database=db_name,
        ssl_disabled=False
    )
    return conn

def generar_cuid():
    timestamp = str(int(time.time() * 1000))
    random_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"c{timestamp}{random_str}"

def procesar_excel(file_content, filename):
    print("Subiendo a Cloudinary...")
    now = datetime.now()
    safe_name = f"Reporte_{now.strftime('%Y%m%d_%H%M%S')}"
    
    upload_result = cloudinary.uploader.upload(
        file_content, 
        resource_type="raw", 
        folder="orbita-respaldos", 
        public_id=f"{safe_name}.xlsx"
    )
    
    cloudinary_url = upload_result.get("secure_url")
    print(f"✅ Excel subido a Cloudinary: {cloudinary_url}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 1. Guardar en RespaldoExcel
    respaldo_id = generar_cuid()
    cursor.execute(
        "INSERT INTO RespaldoExcel (id, nombre, url, fecha) VALUES (%s, %s, %s, %s)",
        (respaldo_id, f"{safe_name}.xlsx", cloudinary_url, now)
    )
    conn.commit()
    
    # 2. Leer y extraer pagos
    df = pd.read_excel(BytesIO(file_content))
    pagos_insertados = 0
    
    for index, row in df.iterrows():
        nombre = str(row.get('DESCRIPCION_DETALLE') or row.get('Nombre') or row.get('Cliente') or 'Desconocido')
        
        monto_raw = row.get('ABONO', 0)
        try:
            monto = float(monto_raw)
        except:
            monto = 0.0
            
        if pd.isna(monto) or monto <= 0:
            continue
            
        fecha_raw = row.get('FECHA_OPERACION')
        if pd.isna(fecha_raw):
            fecha = datetime.now()
        else:
            fecha = pd.to_datetime(fecha_raw).to_pydatetime()
            
        referencia = str(row.get('NO_REFERENCIA', ''))
        if referencia == 'nan': referencia = ''
        
        # 3. Relacionar Cliente y Convenio
        # Buscar si el cliente existe
        cursor.execute("SELECT id FROM Cliente WHERE nombre = %s LIMIT 1", (nombre,))
        cliente_row = cursor.fetchone()
        
        if cliente_row:
            cliente_id = cliente_row[0]
            # Buscar su convenio
            cursor.execute("SELECT id FROM Convenio WHERE clienteId = %s LIMIT 1", (cliente_id,))
            convenio_row = cursor.fetchone()
            convenio_id = convenio_row[0] if convenio_row else None
        else:
            # Crear Cliente
            cliente_id = generar_cuid()
            cursor.execute(
                "INSERT INTO Cliente (id, nombre, email, telefono, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s)",
                (cliente_id, nombre, 'mock@example.com', '5555-5555', now, now)
            )
            # Crear Convenio
            convenio_id = generar_cuid()
            cursor.execute(
                "INSERT INTO Convenio (id, clienteId, montoCuota, diaCorte, estado, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (convenio_id, cliente_id, monto if monto > 0 else 1000.0, 15, 'activo', now, now)
            )
        
        # 4. Insertar Pago final
        pago_id = generar_cuid()
        cursor.execute(
            "INSERT INTO Pago (id, nombreCliente, monto, fecha, referencia, estado, clienteId, convenioId, createdAt) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (pago_id, nombre, monto, fecha, referencia, 'completado', cliente_id, convenio_id, now)
        )
        pagos_insertados += 1
        conn.commit()
        
    print(f"✅ Se insertaron {pagos_insertados} pagos entrelazados con sus Clientes/Convenios.")
    
    cursor.close()
    conn.close()

def cargar_configuracion():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT emailHost, emailUser, emailPassword, emailKeyword FROM Configuracion LIMIT 1")
    config = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not config:
        print("⚠️ No hay configuración en la base de datos.")
        return None
        
    # Desencriptar la contraseña segura
    config['emailPassword'] = decrypt(config.get('emailPassword', ''))
    return config

def procesar_correos():
    config = cargar_configuracion()
    if not config:
        return
        
    email_host = config.get('emailHost') or 'imap.gmail.com'
    email_user = config.get('emailUser')
    email_password = config.get('emailPassword')
    email_keyword = config.get('emailKeyword')

    if not email_user or not email_password:
        print("⚠️ Credenciales incompletas en la base de datos.")
        return

    print("Iniciando conexión IMAP segura...")
    try:
        mail = imaplib.IMAP4_SSL(email_host)
        mail.login(email_user, email_password)
        mail.select("inbox")
        
        status, messages = mail.search(None, 'UNSEEN')
        if status != "OK" or not messages[0]:
            print("No se encontraron correos nuevos.")
            mail.logout()
            return

        email_ids = messages[0].split()
        print(f"Encontrados {len(email_ids)} correos no leídos.")
        
        for e_id in email_ids:
            status, msg_data = mail.fetch(e_id, '(RFC822)')
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])
                    
                    subject, encoding = decode_header(msg["Subject"])[0]
                    if isinstance(subject, bytes):
                        subject = subject.decode(encoding if encoding else "utf-8")
                        
                    print(f"Revisando asunto: '{subject}'")
                    
                    if email_keyword and email_keyword.lower() not in subject.lower():
                        continue
                        
                    print("Descargando adjunto Excel...")
                    
                    excel_encontrado = False
                    for part in msg.walk():
                        if part.get_content_maintype() == 'multipart': continue
                        if part.get('Content-Disposition') is None: continue
                            
                        filename = part.get_filename()
                        if filename and filename.endswith('.xlsx'):
                            file_content = part.get_payload(decode=True)
                            procesar_excel(file_content, filename)
                            excel_encontrado = True
                            
                    if excel_encontrado:
                        # mail.store(e_id, '+FLAGS', '\\Seen')
                        print("Correo procesado.")
                        
        mail.logout()
        print("Finalizado proceso IMAP.")
        
    except Exception as e:
        print(f"Error en IMAP: {e}")

if __name__ == "__main__":
    print("=== Finasist Python Backend ===")
    procesar_correos()
